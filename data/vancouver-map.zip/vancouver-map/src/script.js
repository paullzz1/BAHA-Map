mapboxgl.accessToken = 'pk.eyJ1IjoicGF1bGx6eiIsImEiOiJjbHNueGMxYWgwOHpvMmtuemEydHNmeDV4In0.JetyXo65-dGtsabt-mujBA';
const map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/paullzz/cmh9rkbjt00qn01sm0okrciab',
  center: [-123.047, 49.256], 
  zoom: 9 // starting zoom
    });